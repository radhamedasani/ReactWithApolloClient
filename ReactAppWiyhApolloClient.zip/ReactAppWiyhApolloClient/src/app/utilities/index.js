export const formatCurrency = (currencyVal) => {
   // console.log(`Inside formatCurrency Input CurrencyVal ${currencyVal}`);
    let newCurrencyVal = currencyVal + '';
    const noOfDigits = newCurrencyVal.length;
    let currencyNotation = '';
    if (noOfDigits > 6 && noOfDigits < 10) {
        newCurrencyVal = currencyVal / 1000000;
        currencyNotation = 'm';
    } else if (noOfDigits > 9 && noOfDigits < 13) {
        newCurrencyVal = currencyVal / 1000000000;
        currencyNotation = 'b';
    }
    else if (noOfDigits > 13) {
        newCurrencyVal = currencyVal / 1000000000000;
        currencyNotation = 't'
    } else {
        newCurrencyVal = parseInt(newCurrencyVal);
    }
    newCurrencyVal = formatNumber(newCurrencyVal.toFixed(), {
        style: 'currency',
        currency: 'GBP'
    }) + currencyNotation;
   // console.log(`Inside formatCurrency Formatted Currecy ${newCurrencyVal}`)
    return newCurrencyVal;
}

export const formatNumber = (inputNumber, inputConfig = {}) => {
    const config = Object.assign({}, {
        currency: 'GBP',
        maximumFractionDigits: 0,
        minimumFractionDigits: 0
    }, inputConfig);
    const intFormat = new Intl.NumberFormat('en-GB', config)
    return intFormat.format(inputNumber);
}

export const formatDate = (inputDate) => {
    const dateObj = new Date(inputDate);
    let date = dateObj.getDate();
    date = date < 10 ? `0${date}`: date;
    let month = dateObj.getMonth() + 1;
    month = month < 10 ? `0${month}`: month;
    const newDate = `${dateObj.getFullYear()}-${month}-${date}`;
    return newDate;
}
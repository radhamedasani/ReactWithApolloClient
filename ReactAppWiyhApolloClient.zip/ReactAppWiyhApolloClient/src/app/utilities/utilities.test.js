import React from 'react'
import {formatCurrency,formatDate,formatNumber} from './index'
import { exportAllDeclaration } from '@babel/types';

const currencyVal = 1172340275;

describe('Utility' ,() => {
    describe('Format Currency',() => {
        it('Format Currency with value 1172340275 to £1b',() => {
            expect(formatCurrency(1172340275)).toBe('£1b');
        });
 
        it('Format Number with value 1172340275 to 1,172,340,275',() => {
            expect(formatNumber(1172340275)).toBe('1,172,340,275');
        });

        it('Format Date value from 2018-03-31T00:00:00.000Z to 2018-03-31',() => {
            expect(formatDate('2018-03-31T00:00:00.000Z')).toBe('2018-03-31');
        })

    })
})
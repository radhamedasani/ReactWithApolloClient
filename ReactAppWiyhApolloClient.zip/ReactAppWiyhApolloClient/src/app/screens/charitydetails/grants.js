import React from 'react';
import './styles.css'

import { formatCurrency,formatDate } from '../../utilities'


export const Grants = ({ charity }) => {
    console.log(`grants is ${JSON.stringify(charity)}`);
    const { grants } = charity;
    if (grants) {
        const count = grants.length;
        return (<div>
             <h2 className='grantsCount'>#Grants Details</h2>
            <GrantResults count={count} />
            <GrantAmount charity = {charity}/>
            {count > 0 && <GrantTable grantsList={grants} />}
        </div>);
    }else{
        return(<p id = 'noGrants'>No Grants Received</p>);
    }
}

const GrantAmount = ({charity}) => {
    const {totalIncome,totalGrant,percentageOfGrant} = charity
   return(<div className='horizontalContainer'>
        <p className = 'incomeDetails'>Total Income : {totalIncome}</p>
        <p className ='incomeDetails'>Total Grants Received : {totalGrant}</p>
        <p className = 'incomeDetails'>Percentage Of Grant : {percentageOfGrant}</p>
   </div>);
}

const GrantResults = ({ count }) =>
    <p className='grantsCount'> <b>{count}</b>{` Grants Received`} </p>

const GrantTable = ({ grantsList }) =>
    <table id='grants'>
        <tbody>
            <GrantHeader />
            {
                grantsList.map((item) => <GrantItem {...item} />)
            }
        </tbody>
    </table>

const GrantHeader = () =>
    <tr key='header'>
        <th key='Id'>ID</th>
        <th key='Title'>Title</th>
        <th key='Description'>Description</th>
        <th key='Amount Awarded'>Amount Awarded</th>
        <th key='Award Date'>Award Date</th>
        <th key='Funding Organization'>Funding Organization</th>
    </tr>


const GrantItem = (props) => {
    const { id, title, description, amountAwarded, awardDate, fundingOrganization } = props;
    return (
        <tr key={id}>
            <td id = 'grantId'>{id}</td>
            <td>{title}</td>
            <td>{description}</td>
            <td>{formatCurrency(amountAwarded)}</td>
            <td>{formatDate(awardDate)}</td>
            <td>{fundingOrganization[0].name}</td>
        </tr>
    )
};


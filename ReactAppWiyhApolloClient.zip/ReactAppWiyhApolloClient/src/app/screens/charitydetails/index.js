import React from 'react';
import './styles.css'
import BoxContainer from '../../components/DetailedBox'
import { Grants } from './grants'
export const CharityDetails = (props) => {
    const charity = props.location.state.charity;
    const { description, activities, image } = charity;
    return (<div className='charityContainer'>
        <CharityTitle title={description} />
        <CharityActivities image={image} activities={activities} />
        <CharityAddress charity={charity} />
        <Grants charity={charity} />
    </div>);
}

const CharityTitle = ({ title }) => <h1 id='charityTitle'>{title}</h1>

const CharityActivities = ({ image, activities }) => (
    <div className='horizontalContainer'>
        <img src={image} width="50px" height="50px" alt="Charity" />
        <p id='activityTitle'>{activities}</p>
    </div>
)

const CharityAddress = ({ charity }) => {
    const { contact } = charity;
    const keys = Object.keys(contact);
    let content = {};
    for (let key of keys) {
        if (key !== '__typename' && contact[key] && contact[key] !== '\u0000') {
            content[key] = contact[key];
            if (key === 'address') {
                content[key] = content[key].join(', ');
            }
        }
    }
    return (<BoxContainer title='Contact' content={content}></BoxContainer>);
}
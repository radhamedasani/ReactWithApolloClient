import React from 'react';
import './styles.css'
import { Link } from 'react-router-dom'

import { getCharityData } from './charitydata'
import { formatNumber } from '../../utilities'


export const Charity = ({ charityData }) => {
   const { count, charityList } = getCharityData(charityData);
   return (<div className='charityContainer'>
            <CharityResults count={count} />
            { count > 0 && <CharityTable charityList = {charityList} />}
     </div>);
}

const CharityResults = ({ count }) =>
   <p id='charityCount'> <b>{formatNumber(count)}</b>{` Results Found`} </p>

const CharityTable = ({charityList}) => 
      <table id='charities'>
         <tbody>
            <CharityHeader/>
            {
               charityList.map((item) => <CharityItem key={item.id} {...item}/>)
            }
         </tbody>
      </table>
 
const CharityHeader = () =>
   <tr key='header'>
      <th></th>
      <th>Charity</th>
      <th>Income</th>
      <th>Spending</th>
      <th>Financial Year</th>
   </tr>


const CharityItem = (props) => {
   const { image, description, income, spending, financialYear } = props;
   return (
         <tr>
            <td><img src={image} width="39" height="39" alt = "Charity"/></td>
            <td><Link to= {{ pathname : '/charitydetails',
                             state : {charity:props}}}>
                   {description}
                </Link> </td>
            <td>{income}</td>
            <td>{spending}</td>
            <td>{financialYear}</td>
         </tr>
   )
};


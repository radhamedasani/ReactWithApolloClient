import { formatCurrency } from '../../utilities'

export const getCharityData = (data) => {
   const charityData = data.CHC.getCharities;
   const count = charityData.count;
   const charityList = charityData.list.map((item) => {
      const { finances, image, names, contact } = item;
      const formattedCharity = {
         description: names && names.length > 0 ? names[0].value : '',
         image: image ? (image.logo ? image.logo.small : image) : "images/placeholder.jpg",
         financialYear: getFinancialYear(finances),
         income: finances && finances.length > 0 ? formatCurrency(finances[0].income) : '£0',
         spending: finances && finances.length > 0 ? formatCurrency(finances[0].spending) : '£0',
         contact: contact ? contact : {},
      }
      const grantDetails = getTotalGrantAndIncome(item);
      return Object.assign(item, formattedCharity, grantDetails);
   });
   return {
      count,
      charityList
   }
}

const getFinancialYear = (finances) => {
   const financialYear = finances && finances.length > 0 ? finances[0].financialYear : {}
   const financialYearStart = financialYear.begin ? financialYear.begin.substring(0, 4) : '';
   const financialyearEnd = financialYear.end ? financialYear.end.substring(0, 4) : '';
   return `${financialYearStart}-${financialyearEnd}`
}

const getTotalGrantAndIncome = ({ grants, finances }) => {
   let totalGrant = grants ? grants.reduce((sum, { amountAwarded }) => sum += amountAwarded, 0) : 0;
   let totalIncome = finances ? finances.reduce((sum, { income }) => sum += income, 0) : 0;
   let percentageOfGrant = (parseFloat(totalGrant / totalIncome) * 100).toFixed(2) + '%';

   return {
      totalGrant: formatCurrency(totalGrant),
      percentageOfGrant,
      totalIncome: formatCurrency(totalIncome),
   }
}
import React, { Component, Fragment } from 'react'
import gql from 'graphql-tag'
import { useQuery } from '@apollo/react-hooks'

import { GRAPHQL_QUERIES } from '../../services/queries'
import Header from '../../components/Header'
import SearchBar from '../../components/Search'
import Loading from '../../components/Loading'
import Error from '../../components/Error'
import { Charity } from './charity'

import './styles.css'
export default class CharityList extends Component {

    constructor(props) {
        super(props);
        this.state = {
            searchInput: '',
            searchText: ''
        }
    }
    onClickSearch = () => {
        this.setState({
            searchInput: this.state.searchText
        })
    }

    onTextChange = (event) => {
        this.setState({
            searchText: event.target.value
        })
    }

    render() {
        return (
            <Fragment>
                <Header />
                <SearchBar text={this.state.searchText}
                    onClickSearch={this.onClickSearch}
                    onTextChange={this.onTextChange} />
                <GetCharity {...this.state} />
            </Fragment>

        );
    }
}

const GetCharity = ({ searchInput }) => {
    const { loading, error, data } = useQuery(gql(GRAPHQL_QUERIES.GET_CHARITIES_QUERY), {
        variables: {
            searchInput
        }
    });
    if (loading) return <Loading />
    if (error) return <Error />
    return <CharitySection data={data} />
}

export const CharitySection = ({ data }) =>
    <div>
        <Charity charityData={data} />
    </div>


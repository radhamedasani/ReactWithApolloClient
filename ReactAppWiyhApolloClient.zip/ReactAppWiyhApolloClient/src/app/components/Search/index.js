import React from 'react';
import './styles.css'

const SearchBar = ({ text, onClickSearch, onTextChange }) =>
    <div id='container'>
        <input type="text"
            value={text}
            id='input'
            placeholder='Search By Name'
            onChange={onTextChange} 
            onKeyUp = {(event) => { if(event.keyCode === 13){
               // event.preventDefault();
                onClickSearch()
             }}}/>
        <button type="submit" id='search-bg'
            onClick={onClickSearch}>
            <img id='search' src = "images/search.png" alt = "Search" width = "30px" height = "30px"/>
        </button>
    </div>

export default SearchBar;
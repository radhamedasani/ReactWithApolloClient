import React from 'react'
import './styles.css'

const Loading = () =>
  <p id='loading'>Loading Charities...</p>

export default Loading
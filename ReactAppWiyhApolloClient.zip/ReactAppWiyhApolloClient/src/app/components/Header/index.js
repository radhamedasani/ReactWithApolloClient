import React from 'react'
import './styles.css'

export const Header = () => {
    return (
        <div className='header'>
            <p id='title'>Welcome to Grant Giver</p>
        </div>)
}

export default Header
import React from 'react'
import './styles.css'


const Error = () =>
     <p id='error'>Network Error,Please try again</p>

export default Error;     
import React  from 'react'
import './styles.css'

const BoxContainer = (props) => {
    const { title, content } = props;
    const keys = Object.keys(content);
    return (<div id='boxContainer'>
        <p id='boxHeader'>{title}</p>
        { keys.map((key) => {
            return(content[key] && <p id='boxContent'>{content[key]}</p>)
        })}
    </div>)

}

export default BoxContainer;
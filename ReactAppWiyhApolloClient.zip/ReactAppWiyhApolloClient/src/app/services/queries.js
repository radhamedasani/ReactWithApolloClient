export const GRAPHQL_QUERIES = {
  GET_CHARITIES_QUERY: `query($searchInput:String){
        CHC {
            getCharities(filters: {
                search : $searchInput
            }) {
            count
                list(limit: 30 sort:income_asc) {
                    id
                    names {
                      value
                    }
                    image {
                      logo {
                        small
                      }
                    }
                    finances(all:true) {
                        financialYear {
                            begin
                            end
                        }
                        income
                        spending
                    }  
                    activities

                    grants{
                      id
                      title
                      description
                      awardDate
                      amountAwarded 
                      fundingOrganization {
                        id
                        name
                      }
                    }

                    contact{
                      address
                      email
                      phone
                    }
                }         
            }
        }
    }`
}

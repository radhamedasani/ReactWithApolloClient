import ApolloClient from 'apollo-boost'

const API_TOKEN = 'Apikey 444efbb0-23e6-4147-b53c-18f8fc708b27'
const GRAPHQL_ENDPOINT = 'https://charitybase.uk/api/graphql'

const client = new ApolloClient({
  uri: GRAPHQL_ENDPOINT,
  headers: {
    authorization: API_TOKEN
  }
});

export default client;
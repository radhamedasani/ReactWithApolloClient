import React from 'react';
import { ApolloProvider } from "@apollo/react-hooks"
import client from './app/services/api'
import CharityList from './app/screens/charitylist'
import './App.css';

const App = () => (
  <ApolloProvider client={client}>
    <CharityList />
  </ApolloProvider>
)

export default App;
